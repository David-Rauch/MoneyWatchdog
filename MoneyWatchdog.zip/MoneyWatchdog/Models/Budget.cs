﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MoneyWatchdog.Models;

namespace MoneyWatchdog.Models
{
    public class Budget
    {
        public string Category { get; set; }
    }
}
