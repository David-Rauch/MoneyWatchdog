﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
using Microsoft.SqlServer.Server;

namespace MWTry2.Models
{
    public class GetCsvData
    {
        [Key]
        public int CsvId { get; set; }
        public DateTime CsvDate { get; set; }
        public string CsvName { get; set; }
        public double CsvAmount { get; set; }
    }
}
