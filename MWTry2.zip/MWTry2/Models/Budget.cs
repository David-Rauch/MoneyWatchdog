﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;

namespace MWTry2.Models
{
    public class Budget
    {
        [Key]
        public int BudgetId { get; set; }
        public string Category { get; set; }
    }
}
