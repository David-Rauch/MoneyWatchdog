﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using MWTry2.Models;

namespace MWTry2.Data
{
    public class MWTry2Context : DbContext
    {
        public MWTry2Context (DbContextOptions<MWTry2Context> options)
            : base(options)
        {

        }
        public DbSet<Budget> Budget { get; set; }
        public DbSet<GetCsvData> GetCsvData { get; set; }
        public DbSet<MoneyWatchdog> MoneyWatchdog { get; set; }
    }
}
