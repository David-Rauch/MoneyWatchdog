﻿using Microsoft.AspNetCore.Mvc;
using System.Text.Encodings.Web;

namespace MWTry2.Controllers
{
    public class MWDController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
        public IActionResult Welcome()
        {
            return View();
        }
    }
}